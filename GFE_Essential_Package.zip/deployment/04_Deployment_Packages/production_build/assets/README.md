# assets/

Static assets (CSS, JS, images)

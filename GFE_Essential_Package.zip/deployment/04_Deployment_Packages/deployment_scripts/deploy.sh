#!/bin/bash
# GFE Deployment Script
echo "Deploying GFE Headless Application..."
npm run build
# Add your deployment commands here
echo "Deployment complete!"
